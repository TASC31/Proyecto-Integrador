package view;

import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

import control.ControlProyecto;
import model.Alumno;
import model.Ciclo;

public class VAnadirCic extends JPanel implements IVentanaProyecto {

	private JSpinner spnId;
	private JTextField txtNom;
	private JButton btnInsertar;
	private JTextField txtDesc;

	
	
	public VAnadirCic() {
		inicializar();
	}

	@Override
	public void inicializar() {
		setPreferredSize(new Dimension(430, 280));  
		setLayout(null);
		
		spnId = new JSpinner();
		spnId.setModel(new SpinnerNumberModel(1, 1, 99, 1));
		spnId.setBounds(184, 30, 61, 20);
		add(spnId);
		spnId.setVisible(false);
		
		JLabel lblId = new JLabel("ID :");
		lblId.setBounds(59, 33, 78, 14);
		add(lblId);
		lblId.setVisible(false);
		
		JLabel lblNombre = new JLabel("Nombre :");
		lblNombre.setBounds(59, 89, 115, 14);
		add(lblNombre);
		
		txtNom = new JTextField();
		txtNom.setBounds(184, 86, 160, 20);
		add(txtNom);
		txtNom.setColumns(10);
		
		btnInsertar = new JButton("Insertar Alumno");
		btnInsertar.setBounds(147, 205, 146, 23);
		add(btnInsertar);
		
		JLabel lblDesc = new JLabel("Descripci\u00F3n:");
		lblDesc.setBounds(59, 155, 78, 14);
		add(lblDesc);
		
		txtDesc = new JTextField();
		txtDesc.setColumns(10);
		txtDesc.setBounds(184, 152, 160, 20);
		add(txtDesc);

	}


	public JButton getBtnInsertarCiclo() {
		return btnInsertar;
	}

	public Ciclo InsertarCiclo() {
		int id = (int) spnId.getValue();
		String nom = txtNom.getText();
		String desc = txtDesc.getText();
		Ciclo cic = null;
		
		
			
		if (nom.equals("")) {
			JOptionPane.showMessageDialog(getParent(), 
					"No has puesto un  nombre",
					"Resultado de la operaci�n",
					JOptionPane.INFORMATION_MESSAGE);
			
		} else {
			cic = new Ciclo(id, nom, desc);
			
		}
		
		return cic;
	}
	
	public void mensaje() {
		JOptionPane.showMessageDialog(getParent(), "Ese id ya est� insertado",
				"Resultado de la operaci�n" , JOptionPane.INFORMATION_MESSAGE);
	}

	@Override
	public void setControlador(ControlProyecto control) {
		btnInsertar.addActionListener(control);
		
	}
}
