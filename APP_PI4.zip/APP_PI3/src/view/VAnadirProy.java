package view;

import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

import control.ControlProyecto;
import model.Ciclo;
import model.Proyecto;

public class VAnadirProy extends JPanel implements IVentanaProyecto {
	private JSpinner spnId;
	private JTextField txtNom;
	private JButton btnInsertar;
	private JTextField txtGrupo;
	private JTextField txtUrl;
	private JLabel lblId;
	private JLabel lblNombre;
	private JLabel lblGrupo;
	private JLabel lblNota;
	private JSpinner spinNota;
	private JLabel lblUrl;
	private JLabel lblAo;
	private JSpinner spinAnio;
	private JLabel lblCurso;
	private JTextField txtComp;
	private JSpinner spinCiclo;
	private JSpinner spinCurso;

	
	
	public VAnadirProy() {
		inicializar();
	}

	@Override
	public void inicializar() {
		setPreferredSize(new Dimension(499, 327));  
		setLayout(null);
		
		spnId = new JSpinner();
		spnId.setModel(new SpinnerNumberModel(1, 1, 99, 1));
		spnId.setBounds(184, 27, 61, 20);
		add(spnId);
		spnId.setVisible(false);
		
		lblId = new JLabel("ID :");
		lblId.setBounds(59, 30, 78, 14);
		add(lblId);
		lblId.setVisible(false);
		
		lblNombre = new JLabel("Nombre :");
		lblNombre.setBounds(59, 58, 115, 14);
		add(lblNombre);
		
		txtNom = new JTextField();
		txtNom.setBounds(184, 52, 160, 20);
		add(txtNom);
		txtNom.setColumns(10);
		
		btnInsertar = new JButton("Insertar Proyecto");
		btnInsertar.setBounds(151, 282, 146, 23);
		add(btnInsertar);
		
		lblGrupo = new JLabel("Grupo:");
		lblGrupo.setBounds(59, 189, 78, 14);
		add(lblGrupo);
		
		txtGrupo = new JTextField();
		txtGrupo.setColumns(10);
		txtGrupo.setBounds(184, 186, 160, 20);
		add(txtGrupo);
		
		lblNota = new JLabel("Nota");
		lblNota.setBounds(59, 114, 49, 14);
		add(lblNota);
		
		txtUrl = new JTextField();
		txtUrl.setBounds(184, 83, 160, 20);
		add(txtUrl);
		txtUrl.setColumns(10);
		
		spinNota = new JSpinner();
		spinNota.setBounds(184, 111, 30, 20);
		add(spinNota);
		
		lblUrl = new JLabel("URL");
		lblUrl.setBounds(59, 89, 49, 14);
		add(lblUrl);
		
		lblAo = new JLabel("A\u00F1o");
		lblAo.setBounds(59, 139, 49, 14);
		add(lblAo);
		
		spinAnio = new JSpinner();
		spinAnio.setBounds(184, 136, 30, 20);
		add(spinAnio);
		
		lblCurso = new JLabel("Curso");
		lblCurso.setBounds(59, 164, 49, 14);
		add(lblCurso);
		
		JLabel lblCiclo = new JLabel("Ciclo");
		lblCiclo.setBounds(59, 214, 49, 14);
		add(lblCiclo);
		
		JLabel lblComponentes = new JLabel("Componentes");
		lblComponentes.setBounds(59, 239, 78, 14);
		add(lblComponentes);
		
		txtComp = new JTextField();
		txtComp.setBounds(184, 236, 160, 20);
		add(txtComp);
		txtComp.setColumns(10);
		
		spinCiclo = new JSpinner();
		spinCiclo.setBounds(184, 211, 30, 20);
		add(spinCiclo);
		
		spinCurso = new JSpinner();
		spinCurso.setBounds(184, 161, 30, 20);
		add(spinCurso);

	}


	public JButton getBtnInsertarPro() {
		return btnInsertar;
	}

	public Proyecto InsertarProy() {
		int id = (int) spnId.getValue();
		String nom = txtNom.getText();
		String url = txtUrl.getText();
		int nota = (int) spinNota.getValue();
		int anio = (int) spinAnio.getValue();
		int curso = (int) spinCurso.getValue();
		String grupo = txtGrupo.getText();
		int ciclo = (int) spinCiclo.getValue();
		String comp = txtComp.getText();
		Proyecto pro = null;
		
		
			
		if (nom.equals("")) {
			JOptionPane.showMessageDialog(getParent(), 
					"No has puesto un  nombre",
					"Resultado de la operaci�n",
					JOptionPane.INFORMATION_MESSAGE);
			
		} else {
			pro = new Proyecto(id, nom, url, nota, anio, curso, grupo, ciclo, comp);
			
		}
		
		return pro;
	}
	
	public void mensaje() {
		JOptionPane.showMessageDialog(getParent(), "Ese id ya est� insertado",
				"Resultado de la operaci�n" , JOptionPane.INFORMATION_MESSAGE);
	}

	@Override
	public void setControlador(ControlProyecto control) {
		btnInsertar.addActionListener(control);
		
	}
}
