package model;

public class Usuario {

	private String usuario;
	private String cont;
	
	public Usuario(String usuario, String cont) {
		this.usuario = usuario;
		this.cont = cont;
	}

	public String getUsuario() {
		return usuario;
	}

	public String getCont() {
		return cont;
	}
	
	
}
