package view;

import javax.swing.JPanel;

import control.ControlProyecto;

public class VBorAlu extends JPanel implements IVentanaProyecto {

	@Override
	public void inicializar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setControlador(ControlProyecto control) {
		// TODO Auto-generated method stub

	}

}
