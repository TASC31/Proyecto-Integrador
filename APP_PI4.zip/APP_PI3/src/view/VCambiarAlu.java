package view;

import javax.swing.JPanel;

import control.ControlProyecto;
import model.Alumno;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class VCambiarAlu extends JPanel implements IVentanaProyecto {
	private JTextField txtNombre;
	private JButton btnGuardar;
	private JButton btnVolver;
	private JSpinner spnNum;
	private JSpinner spnId;
	
	public VCambiarAlu() {
		inicializar();
	}

	@Override
	public void inicializar() {
		setLayout(null);
		
		JLabel lblNombre = new JLabel("Nombre y Apellido:");
		lblNombre.setBounds(37, 90, 103, 14);
		add(lblNombre);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(148, 87, 141, 20);
		add(txtNombre);
		txtNombre.setColumns(10);
		
		JLabel lblNum = new JLabel("N� de Expediente:");
		lblNum.setBounds(37, 158, 103, 14);
		add(lblNum);
		
		btnGuardar = new JButton("Guardar Datos");
		btnGuardar.setBounds(37, 243, 159, 23);
		add(btnGuardar);
		
		btnVolver = new JButton("Volver");
		btnVolver.setBounds(351, 243, 89, 23);
		add(btnVolver);
		
		spnNum = new JSpinner();
		spnNum.setModel(new SpinnerNumberModel(100000, 100000, 999999, 1));
		spnNum.setBounds(148, 156, 89, 17);
		add(spnNum);
		
		spnId = new JSpinner();
		spnId.setBounds(148, 34, 29, 20);
		add(spnId);
		spnId.setVisible(false);

	}

	public JButton getBtnGuardar() {
		return btnGuardar;
	}

	public JButton getBtnVolver() {
		return btnVolver;
	}
	
	public void cargarDatosAlumno(Alumno piloto) {
		spnId.setValue(piloto.getId());
		txtNombre.setText(piloto.getNom());
		spnNum.setValue(piloto.getNum());
	
	}
	
	public Alumno obtenerDatosAlumno() {
		int id = (int) spnId.getValue();
		String nom = txtNombre.getText();
		int num = (int) spnNum.getValue();
		Alumno alumno = new Alumno(id, nom, num);
		
		return alumno;
	}
	
	public void mostrarResultado(String msg) {
		JOptionPane.showMessageDialog(getParent(), 
					msg,
					"Resultado de la operaci�n",
					JOptionPane.INFORMATION_MESSAGE);
	}

	@Override
	public void setControlador(ControlProyecto control) {
		btnGuardar.addActionListener(control);
		btnVolver.addActionListener(control);

	}
}