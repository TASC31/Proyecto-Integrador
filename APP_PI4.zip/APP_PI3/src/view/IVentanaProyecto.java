package view;

import control.ControlProyecto;

public interface IVentanaProyecto {
	
	public void inicializar();
	
	public void setControlador(ControlProyecto control);

}
